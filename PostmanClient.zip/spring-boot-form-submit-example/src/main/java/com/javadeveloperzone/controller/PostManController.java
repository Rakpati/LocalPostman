package com.javadeveloperzone.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javadeveloperzone.business.LocalPostMan;

@Controller
public class PostManController {


    @GetMapping("getForm")
    public String getForm() {
        return "postmanClient";
    }

    @PostMapping("/sendDetails")                     
    public String saveDetails(@RequestParam("endPoint") String endPoint,
                              @RequestParam("jsonData") String jsonData,
                              @RequestParam("request") String request,
                              ModelMap modelMap) {

    	System.out.println(request+" ---------------- -----------");
    	LocalPostMan localPostMan = new LocalPostMan();
        modelMap.put("endPoint", endPoint);
        modelMap.put("request", "'"+request+"'");
        modelMap.put("jsonData", localPostMan.postmanProcess(endPoint, request, jsonData));
        
        return "postmanClient";           
    }
}
