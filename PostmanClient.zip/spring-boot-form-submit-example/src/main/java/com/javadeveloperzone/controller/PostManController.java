package com.javadeveloperzone.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javadeveloperzone.business.LocalPostMan;

@Controller
public class PostManController {


    @GetMapping("getForm")
    public String getForm() {
        return "postmanClient";
    }

    @PostMapping("/sendDetails")                     
    public String saveDetails(@RequestParam("endPoint") String endPoint,
                              @RequestParam("jsonData") String jsonData,
                              @RequestParam("request") String request,
                              ModelMap modelMap) {

    	Map<String, String> returnValues = new HashMap<String, String>();
    	
    	LocalPostMan localPostMan = new LocalPostMan();
    	returnValues = localPostMan.postmanProcess(endPoint, request, jsonData);

    	System.out.println(request+" ---------------- -----------");
        modelMap.put("endPoint", endPoint);
        modelMap.put("request", "'"+request+"'");
        modelMap.put("jsonData", returnValues.get("json"));
        modelMap.put("responseCode", returnValues.get("responseCode"));
        
        return "postmanClient";           
    }
}
