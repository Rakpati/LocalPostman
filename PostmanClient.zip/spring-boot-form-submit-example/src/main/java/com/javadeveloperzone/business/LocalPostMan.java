package com.javadeveloperzone.business;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LocalPostMan {

	public String postmanProcess(String endPoint, String request, String json) {

		String POST_PARAMS = "";
		try {
			//System.out.println(POST_PARAMS);
			URL obj = new URL(endPoint);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod(request.toUpperCase()); // change according to the request
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);

			if(request.equalsIgnoreCase("POST") || request.equalsIgnoreCase("PUT")) {
				OutputStream os = postConnection.getOutputStream();
				os.write(json.getBytes()); os.flush(); os.close();

			}
			int responseCode = postConnection.getResponseCode();
			System.out.println("POST Response Code :  " + responseCode);
			System.out.println("POST Response Message : " + postConnection.getResponseMessage());

			BufferedReader in = new BufferedReader(new InputStreamReader(
					postConnection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in .readLine()) != null) {
				response.append(inputLine);
			}
			in .close();
			POST_PARAMS = response.toString().replace("\"", "");
			System.out.println("'"+response.toString()+"'");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
		return POST_PARAMS;
	}

}